import Card from '../../icons/Card';

export default Card;
